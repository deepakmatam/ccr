<?php 

session_start();
error_reporting(E_ERROR | E_PARSE);

$connect = mysqli_connect("localhost","root","","crisk");
if(isset($_POST["submit"]))
{
	$query2= "UPDATE batch SET batch_id = batch_id+1";
	mysqli_query($connect, $query2);
 if($_FILES['predictcr_file']['name'])
 {
  $filename = explode(".", $_FILES['predictcr_file']['name']);
  if(end($filename) == "csv")
  {
   $handle = fopen($_FILES['predictcr_file']['tmp_name'], "r");
   while($data = fgetcsv($handle))
   {
	$cust_name = mysqli_real_escape_string($connect, $data[0]);
    $cust_id = mysqli_real_escape_string($connect, $data[1]);	
    $limit_bal = mysqli_real_escape_string($connect, $data[2]);
    $sex = mysqli_real_escape_string($connect, $data[3]);  
    $education = mysqli_real_escape_string($connect, $data[4]);
    $marriage = mysqli_real_escape_string($connect, $data[5]);
	$age = mysqli_real_escape_string($connect, $data[6]);
	$pay_0 = mysqli_real_escape_string($connect, $data[7]);
	$pay_2 = mysqli_real_escape_string($connect, $data[8]);
	$pay_3 = mysqli_real_escape_string($connect, $data[9]);
	$pay_4 = mysqli_real_escape_string($connect, $data[10]);
	$pay_5 = mysqli_real_escape_string($connect, $data[11]);
	$pay_6 = mysqli_real_escape_string($connect, $data[12]);
	$bill_amt1 = mysqli_real_escape_string($connect, $data[13]);
	$bill_amt2 = mysqli_real_escape_string($connect, $data[14]);
	$bill_amt3 = mysqli_real_escape_string($connect, $data[15]);
	$bill_amt4 = mysqli_real_escape_string($connect, $data[16]);
	$bill_amt5 = mysqli_real_escape_string($connect, $data[17]);
	$bill_amt6 = mysqli_real_escape_string($connect, $data[18]);
	$pay_amt1 = mysqli_real_escape_string($connect, $data[19]);
	$pay_amt2 = mysqli_real_escape_string($connect, $data[20]);
	$pay_amt3 = mysqli_real_escape_string($connect, $data[21]);
	$pay_amt4 = mysqli_real_escape_string($connect, $data[22]);
	$pay_amt5 = mysqli_real_escape_string($connect, $data[23]);
	$pay_amt6 = mysqli_real_escape_string($connect, $data[24]);
	$bill1_lmtbal = ($bill_amt1/$limit_bal);
	$bill2_lmtbal = ($bill_amt2/$limit_bal);
	$bill3_lmtbal = ($bill_amt3/$limit_bal);
	$bill4_lmtbal = ($bill_amt4/$limit_bal);
	$bill5_lmtbal = ($bill_amt5/$limit_bal);
	$bill6_lmtbal = ($bill_amt6/$limit_bal);

	

    $query = "INSERT into input_data (batchID,cust_name,cust_id,limit_bal,sex,education,marriage,age,pay_0,pay_2,pay_3,pay_4,pay_5,pay_6,bill_amt1,bill_amt2,bill_amt3,bill_amt4,bill_amt5,
    bill_amt6,pay_amt1,pay_amt2,pay_amt3,pay_amt4,pay_amt5,pay_amt6,bill1_per_lmtbal,bill2_per_lmtbal,bill3_per_lmtbal,bill4_per_lmtbal,bill5_per_lmtbal,bill6_per_lmtbal) VALUES ((SELECT batch_id FROM batch),'$cust_name','$cust_id','$limit_bal','$sex','$education','$marriage','$age','$pay_0','$pay_2','$pay_3','$pay_4','$pay_5','$pay_6',
			'$bill_amt1','$bill_amt2','$bill_amt3','$bill_amt4','$bill_amt5','$bill_amt6','$pay_amt1','$pay_amt2','$pay_amt3','$pay_amt4','$pay_amt5','$pay_amt6','$bill1_lmtbal','$bill2_lmtbal','$bill3_lmtbal','$bill4_lmtbal','$bill5_lmtbal','$bill6_lmtbal')";
    mysqli_query($connect, $query);
	$query3 = "DELETE FROM `input_data` WHERE `limit_bal` = 0";
    mysqli_query($connect,$query3);
	
	
   }
   fclose($handle);
   $ch = curl_init();

// set URL and other appropriate options
   curl_setopt($ch, CURLOPT_URL, "http://127.0.0.1:5000/model_V1");
   curl_setopt($ch, CURLOPT_HEADER, 0);

// grab URL and pass it to the browser
   curl_exec($ch);

// close cURL resource, and free up system resources
   curl_close($ch);

	   
   }
   
   
   $message = "Data uploaded successfully. Click download report";
   echo "<script type='text/javascript'>alert('$message');</script>";
  }
  else
  {
	include "app.html";  
   $message = 'Please Select CSV File only';
   echo "<script type='text/javascript'>alert('$message');</script>";
   
  }
 }
 else
 {
	 include "app.html";
  $message = "Please Select File";
  echo "<script type='text/javascript'>alert('$message');</script>";
 }


?>
<html>
<style>
input[type=submit] {
    
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 250px 600px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

</style>
<body>
<form method="post" action="export.php">
<input type="submit" value="download report" name= "export">

</form>
<center><a href ="app.html"> Back to Upload Page</a></center>
</body>
</html> 

