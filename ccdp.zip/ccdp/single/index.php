
<!DOCTYPE HTML>
<html lang="en">

<head>
	<title>Single User Prediction</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="CCDP Single user prediction "
	/>
	
	<!-- Meta tag Keywords -->
	<!-- css file -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<!-- //css file -->
	<!-- web-fonts -->
	<link href="//fonts.googleapis.com/css?family=Cuprum:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext,vietnamese"
	    rel="stylesheet">
	<!-- //web-fonts -->

</head>

<body>
	<!-- title -->
	<h1>
		<span>Enter </span>
		<span>Customer</span>
		<span>Details</span>
	</h1>
	<!-- //title -->
	<!-- content -->
	<div class="sub-main-w3">
		<form  validate="true" action="#" method="post">
			<div class="form-group">
				<label for="exampleInputText">Amount of the given credit </label>
				<input type="text" class="form-control" name="name"  placeholder="Enter Amount of the given credit " required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Gender</label>
				<input type="text" class="form-control" name="name"  placeholder="1 = Male; 2 = Female" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Education</label>
				<input type="text" class="form-control" name="name"  placeholder="1 = Graduate school; 2 = University; 3 = High school; 4 = Others" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Marital status</label>
				<input type="text" class="form-control" name="name"  placeholder="1 = Married; 2 = Single; 3 = Others" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText"> Age</label>
				<input type="text" class="form-control" name="name"  placeholder="Enter Age" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Repayment status of last month </label>
				<input type="text" class="form-control" name="name"  placeholder="(-1=pay duly,1=delay for 1 month...9=delay for 9 months and above)" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Repayment status of past second month </label>
				<input type="text" class="form-control" name="name"  placeholder="Same as above scale" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Repayment status of past third month</label>
				<input type="text" class="form-control" name="name"  placeholder="Same as above scale" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Repayment status of past fourth month</label>
				<input type="text" class="form-control" name="name"  placeholder="Same as above scale" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Repayment status of past fifth month</label>
				<input type="text" class="form-control" name="name"  placeholder="Same as above scale" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Repayment status of past sixth month</label>
				<input type="text" class="form-control" name="name"  placeholder="Same as above scale" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Amount of bill statement of last month</label>
				<input type="text" class="form-control" name="name"  placeholder="Net Rupee" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Amount of bill statement of past second month</label>
				<input type="text" class="form-control" name="name"  placeholder="Net Rupee" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Amount of bill statement of past third month</label>
				<input type="text" class="form-control" name="name"  placeholder="Net Rupee" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Amount of bill statement of past fourth month</label>
				<input type="text" class="form-control" name="name"  placeholder="Net Rupee" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Amount of bill statement of past fifth month</label>
				<input type="text" class="form-control" name="name"  placeholder="Net Rupee" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">Amount of bill statement of past sixth month</label>
				<input type="text" class="form-control" name="name"  placeholder="Net Rupee" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">amount paid last month</label>
				<input type="text" class="form-control" name="name"  placeholder="Net Rupee" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">amount paid past second month</label>
				<input type="text" class="form-control" name="name"  placeholder="Net Rupee" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">amount paid past third month</label>
				<input type="text" class="form-control" name="name"  placeholder="Net Rupee" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">amount paid past fourth month</label>
				<input type="text" class="form-control" name="name"  placeholder="Net Rupee" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">amount paid past fifth month</label>
				<input type="text" class="form-control" name="name"  placeholder="Net Rupee" required>
			</div>
			<div class="form-group">
				<label for="exampleInputText">amount paid past sixth month</label>
				<input type="text" class="form-control" name="name"  placeholder="Net Rupee" required>
			</div>
			
			
			<button type="submit" class="btn btn-primary">Check Report</button>
		</form>
	</div>
	<!-- //content -->


	<div class="footer">
		<p>&copy; 2018 CCDP default prediction Form. All rights reserved | visit our site
			<a href="http://deepaktechstuff.000webhostapp.com/">CCDP</a>
		</p>
	</div>


	<!-- Jquery -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<!-- //Jquery -->
	<!-- Jquery -->
	<script src="js/jquery-simple-validator.min.js"></script>
	<!-- //Jquery -->

</body>

</html>
<?php

session_start();
if(!isset($_SESSION['uname']))
{
    // not logged in
    header('Location: index.html');

}

?>

