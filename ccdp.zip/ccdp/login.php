
<?PHP
session_start();
if(isset($_POST['submit']))
{
	$u=$_POST["uname"];
	$p=$_POST["password"];
$_SESSION['uname']=$u;
	$con = mysqli_connect("localhost","root","","crisk");
  $sql="SELECT uname,password FROM buser WHERE uname='$u' and Password='$p'";
  $result=mysqli_query($con,$sql);
  $count  = mysqli_num_rows($result);
  
if($count==0)
{
include 'index.html';
 $message = "Username or Password is incorrect.\\nTry again.";
  echo "<script type='text/javascript'>alert('$message');</script>";


}
else
{
include "app.html";
}
mysqli_close($con);
}
?>
