<?php
 if(isset($_POST["export"]))  
 {  
      $connect = mysqli_connect("localhost", "root", "", "crisk");  
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=report.csv');  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('BatchID', 'CustomerName', 'CustomerID', 'Default_probability', 'Not_Default_prob'));  
      $query = "SELECT *  FROM output_data WHERE batchID = (SELECT batch_id FROM batch)";  
      $result = mysqli_query($connect, $query);  
      while($row = mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);  
 }  


?>