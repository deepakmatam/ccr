<?php
if(isset($_POST['submit'])){
	$input = $_POST['input'];
	$output =$_POST['output'];

if(exec("C:\ProgramData\Anaconda3\python.exe C:/Users/Deepak/PycharmProjects/npaprediction/cc_cmd.py $input $output"))
{
	echo "<h1>something error in file path or server overloaded<h1>";
}else
{
	echo("<center><h1>SUCCESS --- Please check your output file<h1></center>");
}

}


?>