import sys
import numpy as np
import tensorflow as tf
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import os

def predict():
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    input_data = pd.read_csv(input_path, sep=",")[:]
    input_data["BILL_AMT1_PER_LIMIT_BAL"] = input_data["BILL_AMT1"] / input_data["LIMIT_BAL"]
    input_data["BILL_AMT2_PER_LIMIT_BAL"] = input_data["BILL_AMT2"] / input_data["LIMIT_BAL"]
    input_data["BILL_AMT3_PER_LIMIT_BAL"] = input_data["BILL_AMT3"] / input_data["LIMIT_BAL"]
    input_data["BILL_AMT4_PER_LIMIT_BAL"] = input_data["BILL_AMT4"] / input_data["LIMIT_BAL"]
    input_data["BILL_AMT5_PER_LIMIT_BAL"] = input_data["BILL_AMT5"] / input_data["LIMIT_BAL"]
    input_data["BILL_AMT6_PER_LIMIT_BAL"] = input_data["BILL_AMT6"] / input_data["LIMIT_BAL"]
    customer = input_data.iloc[:,0:2]
    input_data = input_data.iloc[:,2:]
    input_data = input_data.values
    input_data = input_data.astype(np.float32)
    scaler = MinMaxScaler(copy=False)
    scaler.fit_transform(input_data[:, 0:1])  # scale LIMIT_BAL
    scaler.fit_transform(input_data[:, 4:5])  # scale age
    scaler.fit_transform(input_data[:, 11:23])  # scale monthly charge and pay
    dirname = os.path.dirname(__file__)
    path1 = os.path.join(dirname, './CC_Default_Trained_Model.ckpt.meta')
    path2 = os.path.join(dirname, './')

    sess = tf.Session()
    # First let's load meta graph and restore weights
    saver = tf.train.import_meta_graph(path1)
    saver.restore(sess, tf.train.latest_checkpoint(path2))

    graph = tf.get_default_graph()
    w1 = graph.get_tensor_by_name("X:0")
    feed_dict = {w1: input_data}
    op_to_restore = graph.get_tensor_by_name("predictions:0")
    result = sess.run(op_to_restore, feed_dict)
    cust_and_result = np.c_[customer, result]
    np.savetxt(output_path, cust_and_result, delimiter=',', fmt='%s')

if __name__ == '__main__':
    predict()





